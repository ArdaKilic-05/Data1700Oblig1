console.log("Hello world form external JavaScript file");
alert("Hello world embedded with JavaScript");