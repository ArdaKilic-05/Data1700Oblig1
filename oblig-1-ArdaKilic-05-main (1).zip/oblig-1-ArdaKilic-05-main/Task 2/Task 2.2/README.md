# Task 2.2
This is the folder where you solve Task 2.2.