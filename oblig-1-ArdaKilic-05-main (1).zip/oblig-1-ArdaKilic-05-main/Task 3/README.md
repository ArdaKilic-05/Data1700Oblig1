# Task 3
This is the folder where you solve both Task 3.1 and 3.2.